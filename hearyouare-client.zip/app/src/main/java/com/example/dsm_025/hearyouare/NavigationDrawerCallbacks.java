package com.example.dsm_025.hearyouare;

public interface NavigationDrawerCallbacks {
    void onNavigationDrawerItemSelected(int position);
}
